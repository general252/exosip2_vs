#include <winsock2.h>
#include <windows.h>

int main(void)
{
	WSAPOLLFD pfd = { INVALID_SOCKET, 0, 0 };
	return 0;
}
