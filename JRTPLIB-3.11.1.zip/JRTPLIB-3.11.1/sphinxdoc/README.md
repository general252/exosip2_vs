Not really using Sphinx documentation, just a small script so that the docs
are automatically generated on readthedocs.
